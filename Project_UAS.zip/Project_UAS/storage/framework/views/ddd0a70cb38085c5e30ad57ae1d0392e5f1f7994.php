

<?php $__env->startSection('title', 'Hotel'); ?>
<?php echo $__env->yieldContent('script'); ?>
<?php $__env->startSection('content'); ?>
<p class="text-center" style="font-size: 36px">Hotel Facilities List</p>
<script>
    $(document).ready(function () {
        $('#hotelfacilities').DataTable();
    });

</script>

<div class="container-fluid">
    <table id="hotelfacilities" class="table table-striped table-bordered" style="width:100%">
        
        <thead>
            <tr>
                <th>ID Hotel</th>
                <th>ID Facility</th>
                <th>Details</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($facility['id_hotel']); ?></td>
                <td><?php echo e($facility['id_facility']); ?></td>
                <td>
                    <a href="<?php echo e(url('admin/hotels/facility/delete/'.$facility['id_hotel'].'/'.$facility['id_facility'])); ?>">Delete</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tfoot>
            <tr>
                <th>ID Hotel</th>
                <th>ID Facility</th>
                <th>Details</th>
            </tr>
        </tfoot>
    </table>
</div>

<div>
    <a href="<?php echo e(url('admin/hotels/facility/add_view/'.$id_hotel)); ?>" class="btn btn-warning">Add Facility</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Project_UAS\resources\views/pages/admin/adminfacility.blade.php ENDPATH**/ ?>