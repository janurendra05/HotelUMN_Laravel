

<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Page Heading -->
    <h1 class="mb-4 text-gray-800 text-center">Booking List</h1>

</div>

<?php for($i = 0; $i < count($booking_list); $i++): ?>
<div class="card m-5">
    <div class="row">
        <div class="col-md-3">
            <?php for($j = 0; $j < count($hotel); $j++): ?>
                <?php if($i == $j): ?>
                    <img class="col-12" src="<?php echo e($hotel[$j]->image_link); ?>">
                    <?php break; ?>
                <?php endif; ?>
            <?php endfor; ?>
            
        </div>
        <div class="col-md-7">
            <div class="card-body">
                <h5 class="card-title">Nomor Pemesanan : <?php echo e($booking_list[$i]->id_booking); ?></h5>
                <?php for($j = 0; $j < count($hotel); $j++): ?>
                    <?php if($i == $j): ?>
                        <p class="card-text">Hotel : <?php echo e($hotel[$j]->name); ?></p>
                        <?php break; ?>
                    <?php endif; ?>
                <?php endfor; ?>
                <p class="card-text">Check-in : <?php echo e($booking_list[$i]->check_in); ?> | Check-out : <?php echo e($booking_list[$i]->check_out); ?></p>
                <p class="card-text">Harga : Rp. <?php echo e($booking_list[$i]->price); ?></p>
            </div>
        </div>
        <div class="col-md-2 text-center">
            <div class="card-body">
                <a class="btn btn-dark" type="submit" href="<?php echo e(url('booking_detail/'.$booking_list[$i]->id_booking)); ?>">Detail</a>
            </div>
        </div>
    </div>
</div>
<?php endfor; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages/app-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Project_UAS\resources\views/pages/user/bookinglist.blade.php ENDPATH**/ ?>