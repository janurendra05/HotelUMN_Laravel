

<?php $__env->startSection('content'); ?>

<div class="container">
  <div class="card mt-5">
    <div class="card-body">
      <a class="btn btn-success" href="<?php echo e(url('home')); ?>">Back</a>
      <h1><?php echo e($hotel['name']); ?></h1>
      <img class="img-fluid" src="<?php echo e($hotel['image_link']); ?>" alt="">
      <div class="rateyo" data-rateyo-rating="<?php echo e($hotel['rating']); ?>" data-rateyo-num-stars="5" data-rateyo-score="<?php echo e($hotel['rating']); ?>"></div>
      <h4><?php echo e($hotel['location']); ?></h4>
      <p><?php echo e($hotel['description']); ?></p>
      <?php if(count($facilities) > 0): ?>
        <p>Fasilitas</p>
        <ul>
          <?php $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($facility->facility_name); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      <?php endif; ?>
  </div>
</div>

<script>
    $(".rateyo").rateYo({
        normalFill: "#A0A0A0",
        starWidth: "25px",
        readOnly: true //--GUNAKAN INI JIKA INGIN DIBUAT DISABLE--
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages/app-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Project_UAS\resources\views/pages/user/hoteldetail.blade.php ENDPATH**/ ?>