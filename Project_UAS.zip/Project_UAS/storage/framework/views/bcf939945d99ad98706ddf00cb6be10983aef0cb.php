

<?php $__env->startSection('content'); ?>

<div class="container">
  <div class="card mt-5">
    <div class="card-body">
      <h1><?php echo e($hotel['name']); ?></h1>
    </div>
  </div>
</div>

<script>
    $(".rateyo").rateYo({
        normalFill: "#A0A0A0",
        starWidth: "25px",
        readOnly: true //--GUNAKAN INI JIKA INGIN DIBUAT DISABLE--
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages/app-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Project_UAS\resources\views/pages/hotel/hoteldetail.blade.php ENDPATH**/ ?>