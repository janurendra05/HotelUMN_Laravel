

<?php $__env->startSection('title', 'Hotel'); ?>
<?php echo $__env->yieldContent('script'); ?>
<?php $__env->startSection('content'); ?>
<p class="text-center" style="font-size: 36px">Hotel Facilities List</p>
<script>
    $(document).ready(function () {
        $('#hoteldetailstable').DataTable();
    });

</script>

<div class="container-fluid">
    <table id="hoteldetailstable" class="table table-striped table-bordered" style="width:100%">
        
        <thead>
            <tr>
                <th>ID Hotel</th>
                <th>Hotel Name</th>
                <th>Location</th>
                <th>Rating</th>
                <th>Details</th>
            </tr>
        </thead>
        <tbody>
            
            
        <tfoot>
            <tr>
                <th>ID Hotel</th>
                <th>Hotel Name</th>
                <th>Location</th>
                <th>Rating</th>
                <th>Details</th>
            </tr>
        </tfoot>
    </table>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Project_UAS\resources\views/pages/admin/adminhotelfacility.blade.php ENDPATH**/ ?>