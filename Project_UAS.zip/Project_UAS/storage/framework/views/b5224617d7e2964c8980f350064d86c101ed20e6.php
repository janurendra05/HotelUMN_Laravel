

<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Page Heading -->
    <h1 class="mb-4 text-gray-800 text-center">Hotel List</h1>

    <div class="row">
        <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-auto">
                <div class="card" style="width: 18rem;">
                    <img src="<?php echo e($hotel['image_link']); ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($hotel['name']); ?></h5>
                        <p class="card-text"><div class="rateyo" data-rateyo-rating="<?php echo e($hotel['rating']); ?>" data-rateyo-num-stars="5" data-rateyo-score="<?php echo e($hotel['rating']); ?>"></div></p>
                        <p class="card-text">Rp. <?php echo e($hotel['price']); ?>/day</p>
                        <a href="<?php echo e(url('hotel/'.$hotel['id_hotel'])); ?>" class="btn btn-secondary">Details</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<!-- /.container-fluid -->

<script>
    $(".rateyo").rateYo({
        normalFill: "#A0A0A0",
        starWidth: "25px",
        readOnly: true //--GUNAKAN INI JIKA INGIN DIBUAT DISABLE--
    });
</script>
<!-- End of Main Content -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages/app-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Project_UAS\resources\views/pages/hotel/home.blade.php ENDPATH**/ ?>