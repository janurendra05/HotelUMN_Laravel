

<?php $__env->startSection('content'); ?>

<div class="container">
    <form action="<?php echo e(url('admin/hotels/room/edit/'.$editroom['id_room'])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="name" class="form-label">ID Room </label>
            <input disabled="disabled" class="form-control" name="id_room" value="<?php echo e($editroom['id_room']); ?>">
        </div>

        <div class="mb-3">
            <label for="name" class="form-label">ID Hotel </label>
            <input disabled="disabled" class="form-control" name="id_hotel" value="<?php echo e($editroom['id_hotel']); ?>">
        </div>

        <div class="mb-3">
            <label for="age" class="form-label">ID Room Type</label>
            <input type="text" class="form-control" name="id_room_type" placeholder="id room type" value="<?php echo e($editroom['id_room_type']); ?>">
        </div>

        <div class="mb-3">
            <label for="age" class="form-label">Price/day</label>
            <input type="text" class="form-control" name="price_per_day" placeholder="price/day" value="<?php echo e($editroom['price_per_day']); ?>">
        </div>

        <div class="mb-3">
            <button type="submit" class="btn btn-primary">Update</button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Project_UAS\resources\views/pages/admin/admineditroom.blade.php ENDPATH**/ ?>