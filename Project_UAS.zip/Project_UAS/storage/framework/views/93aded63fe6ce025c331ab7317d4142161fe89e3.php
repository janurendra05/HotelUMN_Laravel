

<?php $__env->startSection('title', 'Hotel'); ?>
<?php echo $__env->yieldContent('script'); ?>
<?php $__env->startSection('content'); ?>
<p class="text-center" style="font-size: 36px">Hotel Room List</p>
<script>
    $(document).ready(function () {
        $('#hotelroom').DataTable();
    });

</script>


<div class="container-fluid">
    

    <table id="hotelroom" class="table table-striped table-bordered" style="width:100%">
        
        <thead>
            <tr>
                <th>ID Room</th>
                <th>ID Hotel</th>
                <th>Room Type</th>
                <th>Price Per Day</th>
                <th>Details</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($room['id_room']); ?></td>
                <td><?php echo e($room['id_hotel']); ?></td>
                <td><?php echo e($room['id_room_type']); ?></td>
                <td><?php echo e($room['price_per_day']); ?></td>
                <td>
                    <a href="<?php echo e(url('admin/hotels/room/edit_view/' . $room['id_room'])); ?>">Edit Room</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tfoot>
            <tr>
                <th>ID Room</th>
                <th>ID Hotel</th>
                <th>Room Type</th>
                <th>Price Per Day</th>
                <th>Details</th>
            </tr>
        </tfoot>
    </table>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Project_UAS\resources\views/pages/admin/adminroom.blade.php ENDPATH**/ ?>