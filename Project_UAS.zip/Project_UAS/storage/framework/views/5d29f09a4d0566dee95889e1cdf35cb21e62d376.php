<!DOCTYPE html>
<html lang="en">

<head>
    <title>Login V4</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="<?php echo e(url('resources/login/images/icons/favicon.ico')); ?>" />
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('resources/vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(url('resources/login/fonts/font-awesome-4.7.0/css/font-awesome.min.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(url('resources/login/fonts/iconic/css/material-design-iconic-font.min.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('resources/vendor/animate/animate.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('resources/vendor/css-hamburgers/hamburgers.min.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('resources/vendor/animsition/css/animsition.min.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('resources/vendor/select2/select2.min.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('resources/vendor/daterangepicker/daterangepicker.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('resources/login/css/util.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('resources/login/css/main.css')); ?>">
    <!--===============================================================================================-->
</head>

<body>
    <div class="limiter">
        <div class="container-login100" style="background-image: url('<?php echo e(url('resources/login/images/bg-01.jpg')); ?>');">
            <div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54">
                <form class="login100-form validate-form" action=<?php echo e(url('submit_register')); ?> method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <span class="login100-form-title p-b-49">
                        Register
                    </span>

                    <div class="wrap-input100 validate-input" data-validate="Name is required">
                        <span class="label-input100">Full Name</span>
                        <input class="input100" type="text" name="name" placeholder="Type your email">
                        <span class="focus-input100" data-symbol="&#xf206;"></span>
                    </div>

                    <div class="wrap-input100 validate-input" data-validate="Email is required">
                        <span class="label-input100">Email</span>
                        <input class="input100" type="email" name="email" placeholder="Type your email">
                        <span class="focus-input100" data-symbol="&#xf190;"></span>
                    </div>

                    <div class="wrap-input100 validate-input" data-validate="Password is required">
                        <span class="label-input100">Password</span>
                        <input class="input100" type="password" name="password" placeholder="Type your password">
                        <span class="focus-input100" data-symbol="&#xf190;"></span>
                    </div>

                    <div class="wrap-input100 validate-input" data-validate="Password is required">
                        <span class="label-input100">Conrifmation Password</span>
                        <input class="input100" type="password" name="password_confirmation"
                            placeholder="Type your password">
                        <span class="focus-input100" data-symbol=""></span>
                    </div>

                    <div class="wrap-input100 validate-input" data-validate="Birthdate is required">
                        <span class="label-input100">Birthdate</span>
                        <input class="input100" type="date" name="birthdate" placeholder="Input your birthdate">
                        <span class="focus-input100" data-symbol=""></span>
                    </div>

                    <div class="wrap-input100 validate-input" data-validate="Phonenumber is required">
                        <span class="label-input100">Phonenumber</span>
                        <input class="input100" type="text" name="phone_number" placeholder="Type your phonenumber">
                        <span class="focus-input100" data-symbol=""></span>
                    </div>

                    <div class="wrap-input100 ">
                        <span class="label-input100">Profile Picture</span>
                        <input class="input100" type="file" name="link_photo">
                        <span class="focus-input100" data-symbol=""></span>
                    </div>

                    <div class="text-right p-t-8 p-b-31">
                        <!-- <a href="#">
							Forgot password?
						</a> -->
                        <p>
                            <?php if($errors->any()): ?>
                            	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li><?php echo e($error); ?></li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <?php echo e(Session::has('register_failed_message') ? Session::get('register_failed_message') : ''); ?>

                        </p>
                    </div>

                    <div class="container-login100-form-btn">
                        <div class="wrap-login100-form-btn">
                            <div class="login100-form-bgbtn"></div>
                            <button class="login100-form-btn">
                                Register
                            </button>
                        </div>
                    </div>

                    <div class="txt1 text-center p-t-54 p-b-20">
                        <a href="<?php echo e(url('login')); ?>">
                            Already have an account?
                        </a>
                    </div>

                    
                </form>
            </div>
        </div>
    </div>


    <div id="dropDownSelect1"></div>

    <!--===============================================================================================-->
    <script src="<?php echo e(url('resources/vendor/jquery/jquery-3.2.1.min.js')); ?>"></script>
    <!--===============================================================================================-->
    <script src="<?php echo e(url('resources/vendor/animsition/js/animsition.min.js')); ?>"></script>
    <!--===============================================================================================-->
    <script src="<?php echo e(url('resources/vendor/bootstrap/js/popper.js')); ?>"></script>
    <script src="<?php echo e(url('resources/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <!--===============================================================================================-->
    <script src="<?php echo e(url('resources/vendor/select2/select2.min.js')); ?>"></script>
    <!--===============================================================================================-->
    <script src="<?php echo e(url('resources/vendor/daterangepicker/moment.min.js')); ?>"></script>
    <script src="<?php echo e(url('resources/vendor/daterangepicker/daterangepicker.js')); ?>"></script>
    <!--===============================================================================================-->
    <script src="<?php echo e(url('resources/vendor/countdowntime/countdowntime.js')); ?>"></script>
    <!--===============================================================================================-->
    <script src="<?php echo e(url('resources/login/js/main.js')); ?>"></script>

</body>

</html>
<?php /**PATH E:\Project\Project_UAS\resources\views/pages/register.blade.php ENDPATH**/ ?>