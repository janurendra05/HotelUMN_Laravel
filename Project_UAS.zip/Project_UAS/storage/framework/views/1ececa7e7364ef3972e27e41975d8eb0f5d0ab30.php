

<?php $__env->startSection('title', 'Hotel'); ?>
<?php echo $__env->yieldContent('script'); ?>
<?php $__env->startSection('content'); ?>
<p class="text-center" style="font-size: 36px">User List</p>
<script>
    $(document).ready(function () {
        $('#usertable').DataTable();
    });
</script>
<div class="container-fluid mb-1">
    <a type="button" href="<?php echo e(url('admin/users/add_view')); ?>" class="btn btn-warning">Add User</a>
</div>

<div class="container-fluid">
    <table id="usertable" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>ID User</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Birthdate</th>
                <th>Phone Number</th>
                <th>Link Photo</th>
                <th>Role</th>
                <th>Details</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user['id_user']); ?></td>
                <td><?php echo e($user['name']); ?></td>
                <td><?php echo e($user['email']); ?></td>
                <td><?php echo e($user['birthdate']); ?></td>
                <td><?php echo e($user['phone_number']); ?></td>
                <td><?php echo e($user['link_photo']); ?></td>
                <th><?php echo e($user['id_role']); ?></th>
                <td>
                    <a type="button" href="<?php echo e(url('admin/users/edit_view/'.$user['id_user'])); ?>" class="btn btn-warning">Edit</a>
                    <a type="button" href="<?php echo e(url('admin/users/delete/'.$user['id_user'])); ?>" class="btn btn-warning">Delete</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tfoot>
            <tr>
                <th>ID User</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Birthdate</th>
                <th>Phone Number</th>
                <th>Link Photo</th>
                <th>Role</th>
                <th>Details</th>
            </tr>
        </tfoot>
    </table>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Project_UAS\resources\views/pages/admin/adminuser.blade.php ENDPATH**/ ?>