

<?php $__env->startSection('content'); ?>

<div class="container">
    <form action="<?php echo e(url('admin/users/add')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="name" class="form-label">Name</label>
            <input type="text" class="form-control" name="name" placeholder="Type hotel name" value="">
        </div>

        <div class="mb-3">
            <label for="name" class="form-label">Email</label>
            <input type="text" class="form-control" name="email" placeholder="Type email" value="">
        </div>

        <div class="mb-3">
            <label for="name" class="form-label">Password</label>
            <input type="password" class="form-control" name="password" placeholder="Type password" value="">
        </div>

        <div class="mb-3">
            <label for="name" class="form-label">Birthdate</label>
            <input type="date" class="form-control" name="birthdate" placeholder="" value="">
        </div>

        <div class="mb-3">
            <label for="name" class="form-label">Phone Number</label>
            <input type="Number" class="form-control" name="phone_number" placeholder="Type phonenumber" value="">
        </div>

        <div class="mb-3">
            <label for="name" class="form-label">Link photo</label>
            <input type="file" class="form-control" name="link_photo" value="">
        </div>

        <div class="mb-3">
            <label for="name" class="form-label">Role</label>

            <select class="form-control custom-select-sm" name="id_role">
                <option disabled="disabled" selected>Choose user role...</option>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role->id_role); ?>"><?php echo e($role->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3" style="padding-top: 10px">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>

        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($item); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Project_UAS\resources\views/pages/admin/adminuseradd.blade.php ENDPATH**/ ?>