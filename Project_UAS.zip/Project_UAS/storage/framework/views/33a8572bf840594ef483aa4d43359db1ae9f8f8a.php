

<?php $__env->startSection('content'); ?>
<script>
    // $(document).ready(function () {
    //     $('select').selectize({
    //         sortField: 'text'
    //     });
    // });

</script>


<div class="container">
    <form action="" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="name" class="form-label">Hotel Name </label>
            <input type="text" class="form-control" name="" placeholder="Type hotel name" value="">
        </div>

        <div class="mb-3">
            <label for="age" class="form-label">Hotel Name</label>
            <input type="text" class="form-control" name="" placeholder="Quantity" value="">
        </div>
        <script>
            var idx= 0;
        </script>
        <div class="mb-3">
            <label for="age" class="form-label">Pick hotel facility</label> <br>
            
            
            <?php $arrayFacility[] = []; ?>
            <?php for($i = 0; $i < count($editfacilities);): ?>
                <?php $arrayFacility[$i] = $editfacilities[$i]->id_facility ?>
                <?php $i++; ?>
            <?php endfor; ?>

            <?php $index = 0; ?>

            <?php for($i = 0; $i < count($facilities); $i++): ?>
                <input type="checkbox" class="" name="facility<?php echo e($index++); ?>" placeholder="Pick hotel facility" value="<?php echo e($facilities[$i]->id_facility); ?>"
                <?php  ?>> <?php echo e($facilities[$i]->name); ?> <br>
                <?php echo e($facilities[$i]->id_facility); ?>

            <?php endfor; ?>
            
            <input type="hidden" name="count_facility" value="<?php echo e(count($facilities)); ?>">
        </div>

        <div class="mb-3" style="padding-top: 10px">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>

        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($item); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Project_UAS\resources\views/pages/admin/adminfacilityadd.blade.php ENDPATH**/ ?>