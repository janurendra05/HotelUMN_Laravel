

<?php $__env->startSection('content'); ?>
<script>
    // $(document).ready(function () {
    //     $('select').selectize({
    //         sortField: 'text'
    //     });
    // });

</script>


<div class="container">
    <form action="<?php echo e(url('admin/users/edit/'.$useredit['id_user'])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="name" class="form-label">Name</label>
            <input type="text" class="form-control" name="name" placeholder="Type hotel name" value="<?php echo e($useredit['name']); ?>">
        </div>

        <div class="mb-3">
            <label for="name" class="form-label">Email</label>
            <input type="text" name="email" value="<?php echo e($useredit['email']); ?>" hidden>
            <input type="text" class="form-control" placeholder="Type email" value="<?php echo e($useredit['email']); ?>" disabled>
        </div>

        <div class="mb-3">
            <label for="name" class="form-label">Password</label>
            <input type="password" class="form-control" name="password" placeholder="***********" value="">
        </div>

        <div class="mb-3">
            <label for="name" class="form-label">Birthdate</label>
            <input type="date" class="form-control" name="birthdate" placeholder="" value="<?php echo date('Y-m-d',strtotime($useredit['birthdate'])) ?>">
        </div>

        <div class="mb-3">
            <label for="name" class="form-label">Phone Number</label>
            <input type="Number" class="form-control" name="phone_number" placeholder="Type phonenumber" value="<?php echo e($useredit['phone_number']); ?>">
        </div>

        <div class="mb-3">
            <label for="name" class="form-label">Link photo</label>
            <input type="file" class="form-control" name="link_photo" placeholder="" value="<?php echo e($useredit['link_photo']); ?>">
        </div>

        <div class="mb-3">
            <label for="name" class="form-label">Role</label>

            <select class="form-control custom-select-sm" name="id_role">
                
                <?php $options = $useredit->id_role ?>
                <?php $__currentLoopData = $roleedit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role->id_role); ?>" <?php if($options==$role->id_role) echo 'selected="selected"'; ?>><?php echo e($role->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3" style="padding-top: 10px">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>

        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($item); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Project_UAS\resources\views/pages/admin/adminuseredit.blade.php ENDPATH**/ ?>