

<?php $__env->startSection('content'); ?>
<script>
    // $(document).ready(function () {
    //     $('select').selectize({
    //         sortField: 'text'
    //     });
    // });

</script>


<div class="container">
    <form action="<?php echo e(url('admin/hotels/add')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="name" class="form-label">Hotel Name </label>
            <input type="text" class="form-control" name="name" placeholder="Type hotel name" value="">
        </div>

        <div class="mb-3">
            <label for="name" class="form-label">Location </label>

            <select class="form-control custom-select-sm" name="id_location">
                <option disabled="disabled" selected>Choose your location...</option>
                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($location->id_location); ?>"><?php echo e($location->location); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="age" class="form-label">Rating (<span class="fw-light">1 sampai 5</span>) <span class="fw-light">Optional</span></label>
            <input type="number" class="form-control" name="rating" placeholder="0" value="" min="0" max="5">
            
        </div>

        <div class="mb-3">
            <label for="age" class="form-label">Room Quntity</label>
            <input type="number" class="form-control" name="room_quantity" placeholder="Quantity" value="">
        </div>

        <div class="mb-3">
            <label for="age" class="form-label">Price/day</label>
            <input type="number" class="form-control" name="price" placeholder="Price/Day" value="">
        </div>

        <div class="mb-3">
            <label for="age" class="form-label">Pick hotel facility</label> <br>
            <?php $index = 0; ?>
            <?php $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="checkbox" class="" name="facility<?php echo e($index++); ?>" placeholder="Pick hotel facility" value="<?php echo e($facility->id_facility); ?>"> <?php echo e($facility->name); ?> <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <input type="" name="count_facility" value="<?php echo e(count($facilities)); ?>" hidden>
        </div>

        <div class="mb-3">
            <label for="age" class="form-label">Description <span class="fw-light">Optional</span></label>
            <input type="text" class="form-control" name="description" placeholder="" value="" maxlength="255">
        </div>

        <div class="mb-3">
            <label for="age" class="form-label">Hotel Picture <span class="fw-light">Optional</span></label>
            <input type="file" class="form-control" name="image_link" placeholder="" value="">
        </div>

        <div class="mb-3" style="padding-top: 10px">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>

        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($item); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Project_UAS\resources\views/pages/admin/adminadd.blade.php ENDPATH**/ ?>