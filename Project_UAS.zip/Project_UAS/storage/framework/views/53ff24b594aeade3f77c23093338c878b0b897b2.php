

<?php $__env->startSection('content'); ?>

<div class="container">
    <form action="<?php echo e(url('admin/hotels/edit/'.$edithotel['id_hotel'])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        
        <div class="mb-3">
            <label for="name" class="form-label">Hotel ID </label>
            <input disabled="disabled" class="form-control" name="id_hotel" value="<?php echo e($edithotel['id_hotel']); ?>">
        </div>
        
        <div class="mb-3">
            <label for="name" class="form-label">Hotel Name </label>
            <input type="text" class="form-control" name="name" placeholder="name" value="<?php echo e($edithotel['name']); ?>">
        </div>

        <div class="mb-3">
            <label for="name" class="form-label">Hotel ID Location</label>
            <select class="form-control custom-select-sm" name="id_location">
                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($location->id_location); ?>" <?php echo e($location->id_location == $hotel_location['id_location'] ? 'selected' : ''); ?>><?php echo e($location->id_location); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="age" class="form-label">Room Quantity</label>
            <input type="text" class="form-control" name="room_quantity" placeholder="room quantity"
                value="<?php echo e($edithotel['room_quantity']); ?>">
        </div>

        <div class="mb-3">
            <label for="age" class="form-label">Price</label>
            <input type="text" class="form-control" name="price" placeholder="price"
                value="<?php echo e($edithotel['price']); ?>">
        </div>

        <div class="mb-3">
            <label for="age" class="form-label">Description <span class="fw-light">Optional</span></label>
            <input type="text" class="form-control" name="description" placeholder="" value="<?php echo e($edithotel['description']); ?>" maxlength="255">
        </div>

        <div class="mb-3">
            <label for="age" class="form-label">Hotel Picture <span class="fw-light">Optional</span></label>
            <input type="file" class="form-control" name="image_link" placeholder="" value="">
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Project_UAS\resources\views/pages/admin/adminedithotel.blade.php ENDPATH**/ ?>